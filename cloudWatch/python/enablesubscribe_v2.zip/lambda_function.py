import json
import logging
import boto3
import os
import time
from botocore.exceptions import ClientError


def lambda_handler(event, context):
    # TODO implement
    logsclient = boto3.client('logs')
    applySubscriptionToAll = str(event.get('applySubscriptionToAll', None))
    if applySubscriptionToAll == "None":
        if event['detail']['eventName'] == "CreateLogGroup":

            response = logsclient.put_subscription_filter(
                logGroupName=event['detail']['requestParameters']['logGroupName'],
                filterName=os.environ['filterNamePrefix'],
                filterPattern='',
                destinationArn=os.environ['destinationArn'],
                roleArn=os.environ['roleArn']
            )
    elif applySubscriptionToAll == "True":

        next_token = "initialize"
        limit = int(os.environ['limit'])
        countLogGroups = 1
        resultMessage = ""

        #while "nextToken" in logGroups:
        while next_token:
            if str(next_token) != "None":
                prev_token = next_token
            if next_token == "initialize":
                logGroups = logsclient.describe_log_groups(limit=limit)
            else:
                logGroups = logsclient.describe_log_groups(
                    nextToken=next_token, limit=limit)
                time.sleep(2)

            next_token = logGroups.get("nextToken")

            if str(next_token) == "None" and limit != 1:
                next_token = prev_token
                limit = 1
                logGroups = logsclient.describe_log_groups(
                    nextToken=next_token, limit=limit)
                next_token = logGroups.get("nextToken")

            #Iterate through log groups
            for logGroup in logGroups["logGroups"]:
                
                try:
                    logsubscription = logsclient.put_subscription_filter(
                        logGroupName=logGroup["logGroupName"],
                        filterName=os.environ['filterNamePrefix'],
                        filterPattern='',
                        destinationArn=os.environ['destinationArn'],
                        roleArn=os.environ['roleArn'])
                except Exception as e:
                    logging.error('%s-%s', logGroup["logGroupName"], e.response)
                    pass

    elif applySubscriptionToAll == "False":

        next_token = "initialize"
        limit = int(os.environ['limit'])
        countLogGroups = 1
        resultMessage = ""

        #while "nextToken" in logGroups:
        while next_token:

            if str(next_token) != "None":
                prev_token = next_token
            if next_token == "initialize":
                logGroups = logsclient.describe_log_groups(limit=limit)
            else:
                logGroups = logsclient.describe_log_groups(
                    nextToken=next_token, limit=limit)
                time.sleep(2)

            next_token = logGroups.get("nextToken")

            if str(next_token) == "None" and limit != 1:
                next_token = prev_token
                limit = 1
                logGroups = logsclient.describe_log_groups(
                    nextToken=next_token, limit=limit)
                next_token = logGroups.get("nextToken")

            #Iterate through log groups
            for logGroup in logGroups["logGroups"]:
                try:
                    logsubscription = logsclient.delete_subscription_filter(
                        logGroupName=logGroup["logGroupName"],
                        filterName=os.environ['filterNamePrefix'])
                except Exception as e:
                    logging.error(
                        '%s-%s', logGroup["logGroupName"], e.response)
                    pass
                
    else:
        logging.error(
            "None of if condition match. Check input event or parameter")
