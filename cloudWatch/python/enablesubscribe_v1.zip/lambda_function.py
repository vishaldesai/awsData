import json
import boto3
import os
import time
from botocore.exceptions import ClientError


def lambda_handler(event, context):
    # TODO implement
    print(event)
    logsclient = boto3.client('logs')
    applySubscriptionToAll = str(event.get('applySubscriptionToAll', None))
    if applySubscriptionToAll == "None":
        if event['detail']['eventName'] == "CreateLogGroup":

            response = logsclient.put_subscription_filter(
                logGroupName=event['detail']['requestParameters']['logGroupName'],
                filterName='Kinesis',
                filterPattern='',
                destinationArn=os.environ['destinationArn'],
                roleArn=os.environ['roleArn']
            )
    elif applySubscriptionToAll == "True":
        try:
            next_token = "initialize"
            limit = 10
            countLogGroups = 1
            resultMessage = ""

            #while "nextToken" in logGroups:
            while next_token:
                if str(next_token) != "None":
                    prev_token = next_token
                if next_token == "initialize":
                    logGroups = logsclient.describe_log_groups(limit=limit)
                else:
                    logGroups = logsclient.describe_log_groups(
                        nextToken=next_token, limit=limit)
                    time.sleep(5)

                next_token = logGroups.get("nextToken")

                if str(next_token) == "None" and limit != 1:
                    next_token = prev_token
                    limit = 1
                    logGroups = logsclient.describe_log_groups(
                        nextToken=next_token, limit=limit)
                    next_token = logGroups.get("nextToken")

                #Iterate through log groups
                for logGroup in logGroups["logGroups"]:

                    existinglogsubscription = logsclient.describe_subscription_filters(
                        logGroupName=logGroup["logGroupName"])
                    try:
                        firehose = existinglogsubscription["subscriptionFilters"][0]["destinationArn"]
                    except IndexError:
                        firehose = ""
                        pass

                    if "firehose" not in firehose:
                        print (
                            "Adding kinesis subscription filter for log group: " + logGroup["logGroupName"])
                        logsubscription = logsclient.put_subscription_filter(
                            logGroupName=logGroup["logGroupName"],
                            filterName='Kinesis',
                            filterPattern='',
                            destinationArn=os.environ['destinationArn'],
                            roleArn=os.environ['roleArn'])
                    else:
                        print(
                            "Skipping kinesis subscriptin filter for log group: " + logGroup["logGroupName"])

        except ClientError as e:
            print(e.response)
    elif applySubscriptionToAll == "False":

        try:
            next_token = "initialize"
            limit = 10
            countLogGroups = 1
            resultMessage = ""

            #while "nextToken" in logGroups:
            while next_token:

                if str(next_token) != "None":
                    prev_token = next_token
                if next_token == "initialize":
                    logGroups = logsclient.describe_log_groups(limit=limit)
                else:
                    logGroups = logsclient.describe_log_groups(
                        nextToken=next_token, limit=limit)
                    time.sleep(5)

                next_token = logGroups.get("nextToken")

                if str(next_token) == "None" and limit != 1:
                    next_token = prev_token
                    limit = 1
                    logGroups = logsclient.describe_log_groups(
                        nextToken=next_token, limit=limit)
                    next_token = logGroups.get("nextToken")

                #Iterate through log groups
                for logGroup in logGroups["logGroups"]:
                    existinglogsubscription = logsclient.describe_subscription_filters(
                        logGroupName=logGroup["logGroupName"], filterNamePrefix=os.environ['filterNamePrefix'])
                    try:
                        firehose = existinglogsubscription["subscriptionFilters"][0]["destinationArn"]
                    except IndexError:
                        firehose = ""
                        pass

                    if "firehose" in firehose:
                        print (
                            "Deleting kinesis subscription filter for log group: " + logGroup["logGroupName"])
                        logsubscription = logsclient.delete_subscription_filter(
                            logGroupName=logGroup["logGroupName"],
                            filterName=os.environ['filterNamePrefix'])

        except ClientError as e:
            print(e.response)
    else:
        print("None of if condition match")
